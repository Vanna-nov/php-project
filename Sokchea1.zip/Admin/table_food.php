<?php
    include "define/connect.php";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Table</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <div class="container my-3 d-flex justify-content-between">
            <a href="index.php" class="btn btn-primary">Back Home</a>
            <h3>Table Foodies Pets</h3>
            <a href="form_insert_food.php" class="btn btn-primary">Add New</a>
        </div>
    <section class="intro">
        <div class="bg-image h-100" style="background-color: #f5f7fa;">
            <div class="mask d-flex align-items-center h-100">
            <div class="container">
                <div class="row justify-content-center">
                <div class="col-12">
                    <div class="card">
                    <div class="card-body p-0">
                        <div class="table-responsive table-scroll" data-mdb-perfect-scrollbar="true" style="position: relative; height: 700px">
                        <table class="table table-striped mb-0">
                            <thead style="background-color: #002d72;">
                            <tr>
                                <th scope="col" width="70px">ID</th>
                                <th scope="col" >Name</th>
                                <th scope="col" width="100px">Price</th>
                                <th scope="col" width="70px">Quantity</th>
                                <th scope="col" width="120px">Image</th>
                                <th scope="col" width="200px">Category</th>
                                <th scope="col" width="70px">Status</th>
                                <th scope="col" width="200px">Created</th>
                                <th scope="col" width="200px">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $sql="SELECT * FROM tbl_shirt WHERE status=1 ORDER BY id DESC";
                                    $result = mysqli_query($conn,$sql);
                                    while($row=mysqli_fetch_assoc($result)){
                                        ?>
                                            <tr>
                                                <td><?php echo $row['id'] ?></td>
                                                <td><?php echo $row['name'] ?></td>
                                                <td><?php echo $row['price'] ?></td>
                                                <td><?php echo $row['qty'] ?></td>
                                                <td>
                                                    <img src="../img/<?php echo $row['img'] ?>" width="60px" alt="">
                                                </td>
                                                <td><?php echo $row['category'] ?></td>
                                                <td><?php echo $row['status'] ?></td>
                                                <td><?php echo $row['created_at'] ?></td>
                                                <td>
                                                    <a href="form_upd_food.php?id=<?php echo $row['id'] ?>" class="btn btn-primary">Update</a>
                                                    <a href="del_food.php?id=<?php echo $row['id'] ?>" class="btn btn-danger">Delete</a>
                                                </td>
                                            </tr>
                                        <?php
                                    }
                                ?>
                        </tbody>
                        </table>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </div>
    </section>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
