<?php
    include "define/connect.php";
    $id=$_POST['txtid'];
    $name=$_POST['txtname'];
    $price=$_POST['txtprice'];
    $qty=$_POST['txtqty'];
    $status=$_POST['txtstatus'];
    // $categ=$_POST['txtcateg'];
    $date=date('Y-m-d');
    // $target_dir = "../img/";
    // $target_file = $target_dir . basename($_FILES["txtimg"]["name"]);
    // $file_name = basename($_FILES["txtimg"]["name"]);
    // $uploadOk = 1;
    // $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    // if ($uploadOk == 0) {
    //     echo "Sorry, your file was not uploaded.";
    //     // if everything is ok, try to upload file
    //     } else {
    //     if (move_uploaded_file($_FILES["txtimg"]["tmp_name"], $target_file)) {
    //     // echo "The file ". htmlspecialchars( basename(
    //     // $_FILES["fileToUpload"]["name"])). " has been uploaded.";
    //     } else {
    //     echo "Sorry, there was an error uploading your file.";
    //     }
    // }
    $sql = "UPDATE tbl_shirt set name='$name',price=$price,qty=$qty,status=$status where id=$id";
    if(mysqli_query($conn, $sql)){
    header('Location: '.'table_food.php');
    }else{ echo "ERROR: " . mysqli_error($conn); }
?>