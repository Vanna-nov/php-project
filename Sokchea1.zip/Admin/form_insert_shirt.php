<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Table</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <div class="form-data mt-3 bg-primary w-50 m-0 m-auto rounded-3">
            <h2 class="d-flex justify-content-center">Form Data</h2>
            <form action="insert_shirt.php" method="post" enctype="multipart/form-data" class="w-50 m-0 m-auto py-3">
                <label for="id">ID</label>
                <input type="text" name="txtid" id="id" class="form-control" readonly>
                <label for="name">Name</label>
                <input type="text" name="txtname" id="name" class="form-control">
                <label for="price">Price</label>
                <input type="text" name="txtprice" id="price" class="form-control">
                <label for="qty">Quality</label>
                <input type="text" name="txtqty" id="qty" class="form-control">
                <label for="img">Photo</label>
                <input type="file" name="txtimg" id="img" class="form-control">
                <label for="status">Status</label>
                <select name="txtstatus" id="status" class="form-control">
                    <option value="1">1</option>
                    <option value="0">0</option>
                </select>
                <input type="submit" value="Save" class="btn btn-warning mt-2">
            </form>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>