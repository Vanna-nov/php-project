<?php
    include "define/connect.php";
    $id=$_GET['id'];
    $sql = "UPDATE tbl_user set status=0 where id=$id";
    if(mysqli_query($conn, $sql)){
    header('Location: '.'table_user.php');
    }else{ echo "ERROR: " . mysqli_error($conn); }
?>