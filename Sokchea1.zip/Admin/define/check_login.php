<?php
    include ("connect.php");
    session_start();
    $user= $_POST['txt-uname'];
    $pwd= md5($_POST['txt-pwd']);
    $sql="SELECT * from tbl_user where uname='$user' and pwd='$pwd'";
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result) > 0){
        $_SESSION['login']=$user;
        header('Location:'.' ../index.php');
    }else{
        header('Location:'.'../../login.php');
    }
?>