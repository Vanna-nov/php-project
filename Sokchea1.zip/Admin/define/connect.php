<?php
    $server='localhost';
    $user='root';
    $pwd='';
    $db='db_pro';
    $conn=mysqli_connect($server,$user,$pwd,$db);
    if(!$conn){
        echo "NO Connect";
    }
?>