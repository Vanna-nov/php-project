<?php
    include "define/connect.php";
    $id=$_GET['id'];
    $sql = "UPDATE tbl_product set status=0 where id=$id";
    if(mysqli_query($conn, $sql)){
    header('Location: '.'table_shirt.php');
    }else{ echo "ERROR: " . mysqli_error($conn); }
?>