<?php
    include "define/connect.php";

    $name=$_POST['txtname'];
    $price=$_POST['txtprice'];
    $qty=$_POST['txtqty'];
    $status=$_POST['txtstatus'];
    $date=date('Y-m-d');
    $target_dir = "../img/";
    $target_file = $target_dir . basename($_FILES["txtimg"]["name"]);
    $file_name = basename($_FILES["txtimg"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
        } else {
        if (move_uploaded_file($_FILES["txtimg"]["tmp_name"], $target_file)) {
        // echo "The file ". htmlspecialchars( basename(
        // $_FILES["fileToUpload"]["name"])). " has been uploaded.";
        } else {
        echo "Sorry, there was an error uploading your file.";
        }
    }
    $sql = "INSERT INTO tbl_product VALUES (null,'$name','$price','$qty','$file_name','$status','$date')";
    if(mysqli_query($conn, $sql)){
    header('Location: '.'table_shirt.php');
    }else{ echo "ERROR: " . mysqli_error($conn); }
?>